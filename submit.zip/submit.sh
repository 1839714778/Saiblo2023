rm submit.zip
zip -r submit.zip * 
cp submit.zip /mnt/c/Users/NINGMEI/Desktop
